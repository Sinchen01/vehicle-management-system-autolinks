﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace _Vehicle_service
{
    public partial class Login1 : System.Web.UI.Page
    {
        bll b = new bll();
        DataTable Tab;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void lgn_btn_Click(object sender, EventArgs e)
        {
            string str1,str2;
            str1=txtemail.Text;
            str2=txtpassword.Text;
              bool n;
            switch (DropDownList1.SelectedItem.Text)
            {
                case "Admin":
                    if (str1 == "Admin" && str2 == "Admin")
                    {

                        Response.Redirect("~/_Service_Center/_Service.aspx");
                    }
                    else
                    {
                        Response.Write("<script>alert('Invalide LoginId and Password')</script>");
                    }
                    break;

                case "Service Provider":
                   n= b.IsvalidUser(txtemail.Text, txtpassword.Text, DropDownList1.SelectedItem.Text);
                    if (n)
                    {

                        Tab = b._GetUserData(txtemail.Text, txtpassword.Text);
                        Session["RegisterId"] = Tab.Rows[0]["RegisterId"].ToString();
                        Response.Redirect("~/_ServiceProvider/_ServiceProviders.aspx");

                    }
                    else
                    {
                        Response.Write("<script>alert('Invalide LoginId and Password')</script>");
                    }
                    break;
                case "Customer":
                    n = b.IsvalidUser(txtemail.Text, txtpassword.Text, DropDownList1.SelectedItem.Text);
                    if (n)
                    {

                        Tab = b._GetUserData(txtemail.Text, txtpassword.Text);
                        Session["RegisterId"] = Tab.Rows[0]["RegisterId"].ToString();
                        Session["EmailId"] = Tab.Rows[0]["EmailId"].ToString();
                        Response.Redirect("~/Customer/_Customer.aspx");

                    }
                    else
                    {
                        Response.Write("<script>alert('Invalide LoginId and Password')</script>");
                    }

                    break;
            }
        }
    }
}