﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data;
using MySql.Data.MySqlClient;
using MySql.Data.Common;
using MySql.Data;

namespace _Vehicle_service
{
    public class bll
    {
        MySqlConnection con = null;

        MySqlCommand cmd = null;

        public bll()
        {
            con = new MySqlConnection("server=sg2nlmysql35plsk.secureserver.net;database=carservice;user id=usrcarservice;pwd=bkgV55*2");
            con.Open();
            cmd = new MySqlCommand();
            cmd.Connection = con;
        }
        //Admin
        public bool Isvalidadmin(string LoginId,string Password)
        {
            string Mysql = string.Format("select count(*) from tblAdmin where LoginId='{0}' and Password='{1}'", LoginId, Password);
            cmd.CommandText = Mysql;
            int n = int.Parse(cmd.ExecuteScalar().ToString());
            if (n == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //Customer
        public bool CheckUseremail(string EmailId)
        {
            string Mysql = string.Format("select count(*) from tblRegister where EmailId='{0}'", EmailId);
            cmd.CommandText = Mysql;
            int n = int.Parse(cmd.ExecuteScalar().ToString());
            if (n == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool user_register(string RegisterType,string Name, string EmailId, string Password,string Mobile)
        {
            try
            {
                string MySql = string.Format("INSERT INTO tblRegister (RegisterType,Name,EmailId,Password,Mobile) values('{0}','{1}','{2}','{3}','{4}')", RegisterType, Name, EmailId, Password,Mobile);
                cmd.CommandText = MySql;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (MySqlException)
            {
                return false;
            }
        }
        public bool IsvalidUser(string EmailId, string Password, string RegisterType)
        {
            string Mysql = string.Format("select count(*) from tblRegister where EmailId='{0}' and Password='{1}' and RegisterType='{2}'", EmailId, Password, RegisterType);
            cmd.CommandText = Mysql;
            int n = int.Parse(cmd.ExecuteScalar().ToString());
            if (n == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public DataTable _GetUserData(string EmailId, string Password)
        {
            string MySql = String.Format("select * from tblRegister where EmailId='{0}' and Password='{1}'", EmailId, Password);
            cmd.CommandText = MySql;
            cmd.ExecuteNonQuery();
            MySqlDataAdapter odp = new MySqlDataAdapter(MySql, con);
            DataTable dt = new DataTable();
            odp.Fill(dt);
            return (dt);

           
        }
        public DataTable _GetUserData_RegId(int RegisterId)
        {
            string MySql = String.Format("select * from tblRegister where RegisterId={0}", RegisterId);
            cmd.CommandText = MySql;
            cmd.ExecuteNonQuery();
            MySqlDataAdapter odp = new MySqlDataAdapter(MySql, con);
            DataTable dt = new DataTable();
            odp.Fill(dt);
            return (dt);


        }
        public DataTable _GetRegisterData(string RegisterType)
        {
            string MySql = String.Format("select DISTINCT EmailId,Contactname,Contactnumber,Address,tblRegister.RegisterId,tblRegister.Name,gpsdata from  tblServiceDetails INNER JOIN tblRegister ON tblRegister.RegisterId = tblServiceDetails.CustomerId where RegisterType='{0}'", RegisterType);
            cmd.CommandText = MySql;
            cmd.ExecuteNonQuery();
            MySqlDataAdapter odp = new MySqlDataAdapter(MySql, con);
            DataTable dt = new DataTable();
            odp.Fill(dt);
            return (dt);


        }
        public DataTable _GetRegisterCustomerData(string RegisterType)
        {
            string MySql = String.Format("select * from  tblRegister where RegisterType='{0}'", RegisterType);
            cmd.CommandText = MySql;
            cmd.ExecuteNonQuery();
            MySqlDataAdapter odp = new MySqlDataAdapter(MySql, con);
            DataTable dt = new DataTable();
            odp.Fill(dt);
            return (dt);


        }
        //Service Type
         public bool CheckService(string Service)
        {
            string Mysql = string.Format("select count(*) from tblServicetype where Servicetype='{0}'", Service);
            cmd.CommandText = Mysql;
            int n = int.Parse(cmd.ExecuteScalar().ToString());
            if (n == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
         public bool Updateservicetype(string servicetype, int ServiceTypeId)
         {
             try
             {
                 string MySql = string.Format("UPDATE tblServicetype SET Servicetype='{0}' where ServiceTypeId={1}", servicetype, ServiceTypeId);
                 cmd.CommandText = MySql;
                 cmd.ExecuteNonQuery();
                 return true;

             }
             catch (MySqlException)
             {
                 return false;
             }
         }
         public bool Upload_Service(string Servicetype)
         {
             try
             {
                 string MySql = string.Format("INSERT INTO tblServicetype (Servicetype) values('{0}')", Servicetype);
                 cmd.CommandText = MySql;
                 cmd.ExecuteNonQuery();
                 return true;



             }
             catch (MySqlException)
             {
                 return false;
             }
         }
         public DataTable _GetServiceList()
         {
             string MySql = String.Format("select *from tblServicetype");
             cmd.CommandText = MySql;
             cmd.ExecuteNonQuery();
             MySqlDataAdapter odp = new MySqlDataAdapter(MySql, con);
             DataTable dt = new DataTable();
             odp.Fill(dt);
             return (dt);
         }
         //Vehicle Type

         public bool CheckVehicleType(string VehicleType)
         {
             string Mysql = string.Format("select count(*) from tblVehicle_type where VehicleType='{0}'", VehicleType);
             cmd.CommandText = Mysql;
             int n = int.Parse(cmd.ExecuteScalar().ToString());
             if (n == 1)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }
         public bool Upload_VehicleType(string VehicleType)
         {
             try
             {
                 string MySql = string.Format("INSERT INTO tblVehicle_type (VehicleType) values('{0}')", VehicleType);
                 cmd.CommandText = MySql;
                 cmd.ExecuteNonQuery();
                 return true;



             }
             catch (MySqlException)
             {
                 return false;
             }
         }

         public DataTable _GetVehicle_typeList()
         {
             string MySql = String.Format("select *from tblVehicle_type");
             cmd.CommandText = MySql;
             cmd.ExecuteNonQuery();
             MySqlDataAdapter odp = new MySqlDataAdapter(MySql, con);
             DataTable dt = new DataTable();
             odp.Fill(dt);
             return (dt);
         }
         public DataTable _GetService_Details(int SelectTypeId)
         {
             string MySql = String.Format("select *from tblServiceDetails where SelectTypeId={0}", SelectTypeId);
             cmd.CommandText = MySql;
             cmd.ExecuteNonQuery();
             MySqlDataAdapter odp = new MySqlDataAdapter(MySql, con);
             DataTable dt = new DataTable();
             odp.Fill(dt);
             return (dt);
         }
         public bool UpdateVehicletype(string Vehicletype, int VehicletypeId)
         {
             try
             {
                 string MySql = string.Format("UPDATE tblVehicle_type SET VehicleType='{0}' where Vehicle_typeId={1}", Vehicletype, VehicletypeId);
                 cmd.CommandText = MySql;
                 cmd.ExecuteNonQuery();
                 return true;

             }
             catch (MySqlException)
             {
                 return false;
             }
         }

        //Service Details
        public bool Upload_ServiceDetails(int CustomerId,string Contactname,string Contactnumber,string Address,string Latitude,string Longitude,int SelectTypeId,int Charge,string ServiceDetails,string gpsdata)
        {
            try
            {
                string MySql = string.Format("INSERT INTO tblServiceDetails (CustomerId,Contactname,Contactnumber,Address,Latitude,Longitude,SelectTypeId,Charge,ServiceDetails,gpsdata) values({0},'{1}','{2}','{3}','{4}','{5}',{6},{7},'{8}','{9}')", CustomerId, Contactname, Contactnumber, Address, Latitude, Longitude, SelectTypeId, Charge, ServiceDetails, gpsdata);
                cmd.CommandText = MySql;
                cmd.ExecuteNonQuery();
                return true;



            }
            catch (MySqlException)
            {
                return false;
            }
    
        }
        public DataTable _GetCustomer_Upload_ServiceDetails(int CustomerId)
        {
            string MySql = String.Format("select *from tblServiceDetails where CustomerId='{0}'", CustomerId);
            cmd.CommandText = MySql;
            cmd.ExecuteNonQuery();
            MySqlDataAdapter odp = new MySqlDataAdapter(MySql, con);
            DataTable dt = new DataTable();
            odp.Fill(dt);
            return (dt);
        }
        public DataTable _GetCustomer_ServiceDetails(int ServiceDetailsId)
        {
            string MySql = String.Format("select *from tblServiceDetails where ServiceDetailsId={0}", ServiceDetailsId);
            cmd.CommandText = MySql;
            cmd.ExecuteNonQuery();
            MySqlDataAdapter odp = new MySqlDataAdapter(MySql, con);
            DataTable dt = new DataTable();
            odp.Fill(dt);
            return (dt);
        }
        //Service Details
        public bool Upload_ServiceRequest(int ServiceDetailsId, int ServiceProvierId,string TimeStamp, string Status,string EmailId)
        {
            try
            {
                string MySql = string.Format("INSERT INTO ServiceRequest(ServiceDetailsId,ServiceProvierId,TimeStamp,Status,EmailId) values({0},{1},'{2}','{3}','{4}')", ServiceDetailsId, ServiceProvierId, TimeStamp, Status, EmailId);
                cmd.CommandText = MySql;
                cmd.ExecuteNonQuery();
                return true;



            }
            catch (MySqlException)
            {
                return false;
            }

        }
        public bool UpdateServiceRequest(string Status, int RequestId)
        {
            try
            {
                string MySql = string.Format("UPDATE ServiceRequest SET Status='{0}' where RequestId={1}", Status, RequestId);
                cmd.CommandText = MySql;
                cmd.ExecuteNonQuery();
                return true;

            }
            catch (MySqlException)
            {
                return false;
            }
        }
        public DataTable ServiceRequest(int ServiceProvierId)
        {
            string MySql = String.Format("SELECT RequestId,tblRegister.Name,Mobile,TimeStamp,Status,ServiceDetailsId FROM ServiceRequest INNER JOIN tblRegister ON tblRegister.RegisterId = ServiceRequest.ServiceProvierId  where ServiceRequest.ServiceProvierId={0}", ServiceProvierId);
            cmd.CommandText = MySql;
            cmd.ExecuteNonQuery();
            MySqlDataAdapter odp = new MySqlDataAdapter(MySql, con);
            DataTable dt = new DataTable();
            odp.Fill(dt);
            return (dt);
        }

        public DataTable RequestStatus(string EmailId)
        {
            string MySql = String.Format("SELECT TimeStamp,Status FROM ServiceRequest where EmailId='{0}'", EmailId);
            cmd.CommandText = MySql;
            cmd.ExecuteNonQuery();
            MySqlDataAdapter odp = new MySqlDataAdapter(MySql, con);
            DataTable dt = new DataTable();
            odp.Fill(dt);
            return (dt);
        }
       

        
    }   


}