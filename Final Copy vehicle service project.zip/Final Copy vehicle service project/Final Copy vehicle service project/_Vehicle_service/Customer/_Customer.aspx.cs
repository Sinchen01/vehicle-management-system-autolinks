﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _Vehicle_service.Customer
{
    public partial class _Customer : System.Web.UI.Page
    {
        bll b = new bll();
        int RegisterId;
        protected void Page_Load(object sender, EventArgs e)
        {
            RegisterId = int.Parse(Session["RegisterId"].ToString());
            if (!IsPostBack)
            {
                bindcustomer();
            }
        }
        private void bindcustomer()
        {
            GridView1.DataSource = b._GetUserData_RegId(RegisterId);
            GridView1.DataBind();
        }
    }
}