﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _Vehicle_service.Customer
{
    public partial class RequestStatus : System.Web.UI.Page
    {
        bll b = new bll();
        int RegisterId;
        string EmailId;

        protected void Page_Load(object sender, EventArgs e)
        {
            RegisterId = int.Parse(Session["RegisterId"].ToString());
            EmailId = Session["EmailId"].ToString();
            if (!IsPostBack)
            {

                GridView1.DataSource = b.RequestStatus(EmailId);
                GridView1.DataBind();

                if (GridView1.Rows.Count == 0)
                {
                    Response.Write("<script>alert('No data Available')</script>");

                }
                else
                {
                    GridView1.DataSource = b.RequestStatus(EmailId);
                    GridView1.DataBind();
                }
               

            }
        }

       


       
           

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            GridView1.DataSource = b.RequestStatus(EmailId);
            GridView1.DataBind();//bindgridview will get the data source and bind it again
        }
    }
}