﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _Vehicle_service.Customer
{
    public partial class _ServiceCenter : System.Web.UI.Page
    {
        bll b = new bll();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindVehicle();
                DropDownList1.Items.Insert(0, "Select");
            }
        }
        public void BindVehicle()
        {
            DropDownList1.DataSource = b._GetVehicle_typeList();
            DropDownList1.DataTextField = "VehicleType";
            DropDownList1.DataValueField = "Vehicle_typeId";
            DropDownList1.DataBind();

        }
        public void BindService()
        {
            GridView1.DataSource = b._GetService_Details(int.Parse(DropDownList1.SelectedItem.Value));
            GridView1.DataBind();
        }
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            BindService();//bindgridview will get the data source and bind it again
        }
     
        protected void upload_btn_Click(object sender, EventArgs e)
        {
            BindService();
            if (GridView1.Rows.Count == 0)
            {
                Response.Write("<script>alert('No data Available')</script>");
                
            }
            else
            {
                BindService();
            }
        }
    }
}