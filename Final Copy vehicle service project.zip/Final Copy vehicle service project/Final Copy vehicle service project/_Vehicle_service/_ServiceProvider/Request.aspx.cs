﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _Vehicle_service._ServiceProvider
{
    public partial class Request : System.Web.UI.Page
    {
        bll b = new bll();
        int RegisterId;
        protected void Page_Load(object sender, EventArgs e)
        {
            RegisterId = int.Parse(Session["RegisterId"].ToString());
            if (!IsPostBack)
            {

                BindService();
                MultiView1.SetActiveView(View1);
                
            }
        }
        
        public void BindService()
        {
            GridView1.DataSource = b.ServiceRequest(RegisterId);
            GridView1.DataBind();
        }
        
        
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            BindService();//bindgridview will get the data source and bind it again
        }

        protected void upload_btn_Click(object sender, EventArgs e)
        {
            BindService();
            if (GridView1.Rows.Count == 0)
            {
                Response.Write("<script>alert('No data Available')</script>");
                BindService();
            }
            else
            {
                BindService();
            }
        }

      
        protected void btn_view_Click(object sender, EventArgs e)
        {
           
            int ServiceDetailsId = int.Parse(((Button)sender).CommandArgument);
            GridView2.DataSource = b._GetCustomer_ServiceDetails(ServiceDetailsId);
            GridView2.DataBind();
            MultiView1.SetActiveView(View2);
        }

        protected void btn_back_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View1);
        }

       
        

        protected void Accept_btn_Click(object sender, EventArgs e)
        {
            int RequestId = int.Parse(((Button)sender).CommandArgument);
            bool res = b.UpdateServiceRequest("Accepted", RequestId);
            if (res)
            {
                Response.Write("<script>alert('Service Request Status Updated')</script>");
                
                BindService(); ;
            }
            else
            {
                Response.Write("<script>alert('Error..!!!!!')</script>");
                
                BindService();
            }
        }

        protected void Reject_btn_Click(object sender, EventArgs e)
        {
            int RequestId = int.Parse(((Button)sender).CommandArgument);
            bool res = b.UpdateServiceRequest("Rejected", RequestId);
            if (res)
            {
                Response.Write("<script>alert('Service Request Status Updated')</script>");
               
                BindService(); ;
            }
            else
            {
                Response.Write("<script>alert('Error..!!!!!')</script>");
               
                BindService();
            }
        }

       
        

     

    }
}