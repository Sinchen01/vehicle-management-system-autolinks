﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _Vehicle_service._ServiceProvider
{
    public partial class _MyserviceDetail : System.Web.UI.Page
    {
        bll b = new bll();
        int RegisterId;
        protected void Page_Load(object sender, EventArgs e)
        {
            RegisterId = int.Parse(Session["RegisterId"].ToString());
            if (!IsPostBack)
            {
                binddetails();

            }
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            binddetails();//bindgridview will get the data source and bind it again
        }
        private void binddetails()
        {
            GridView1.DataSource = b._GetCustomer_Upload_ServiceDetails(RegisterId);
            GridView1.DataBind();
        }
    }
}