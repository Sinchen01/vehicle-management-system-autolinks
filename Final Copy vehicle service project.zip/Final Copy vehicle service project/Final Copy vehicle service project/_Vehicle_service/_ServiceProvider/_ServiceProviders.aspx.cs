﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using MySql.Data.MySqlClient;
using MySql.Data.Common;
using MySql.Data;
using System.Text;

using System.Device.Location;

namespace _Vehicle_service._ServiceProvider
{
    public partial class _ServiceProviders : System.Web.UI.Page
    {
        bll b = new bll();
        int RegisterId;
        static string Latitude, Longitude;
        protected void Page_Load(object sender, EventArgs e)
        {
            RegisterId = int.Parse(Session["RegisterId"].ToString());
            if (!IsPostBack)
            {
                GetLocationProperty();
                BindService();
                BindVehicle();
                DropDownList1.Items.Insert(0, "Select");
                txtlat.Text = Latitude;
                txtlon.Text = Longitude;
                
            }

        }
        public void BindVehicle()
        {
            DropDownList1.DataSource = b._GetVehicle_typeList();
            DropDownList1.DataTextField = "VehicleType";
            DropDownList1.DataValueField = "Vehicle_typeId";
            DropDownList1.DataBind();

        }
        static void GetLocationProperty()
        {
            GeoCoordinateWatcher watcher = new GeoCoordinateWatcher();

            // Do not suppress prompt, and wait 1000 milliseconds to start.
            watcher.TryStart(false, TimeSpan.FromMilliseconds(1000));

            GeoCoordinate coord = watcher.Position.Location;

            if (coord.IsUnknown != true)
            {

                Latitude = coord.Latitude.ToString();
                    Longitude = coord.Longitude.ToString();
            }
            else
            {
                coord.Latitude = 0;
                coord.Longitude = 0;

            }
        }
        public void BindService()
        {
            GridView1.DataSource = b._GetServiceList();
            GridView1.DataBind();
        }
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            BindService();//bindgridview will get the data source and bind it again
        }

        protected void upload_btn_Click(object sender, EventArgs e)
        {
            StringBuilder str = new StringBuilder();
            string srvc;
            foreach (GridViewRow gvrow in GridView1.Rows)
            {
                var checkbox = gvrow.FindControl("CheckBox1") as CheckBox;

                Label servicetype = (Label)gvrow.FindControl("lblservicetype");


                if (checkbox.Checked)
                {

                    str.Append(servicetype.Text + ",");

                }

            }
            srvc = str.ToString();
            bool res = b.Upload_ServiceDetails(RegisterId, txtname.Text, txtcontact.Text, txtaddress.Text, txtlat.Text, txtlon.Text, int.Parse(DropDownList1.SelectedItem.Value), int.Parse(txtcharge.Text), srvc, txtlat.Text+" "+txtlon.Text);
            if (res)
            {
                Response.Write("<script>alert('Data Uploaded')</script>");
            }
            else
            {
                Response.Write("<script>alert('Error..!!')</script>");
            }
        }
    }
}