﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _Vehicle_service._Service_Center
{
    public partial class _VehicleType : System.Web.UI.Page
    {
        bll b = new bll();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Bindvehicletype();
            }

        }
        public void Bindvehicletype()
        {
            GridView1.DataSource = b._GetVehicle_typeList();
            GridView1.DataBind();
        }
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            Bindvehicletype();//bindgridview will get the data source and bind it again
        }
        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            Bindvehicletype();
        }
        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            Bindvehicletype();
        }
       
        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow r = GridView1.Rows[e.RowIndex];
            Button lblId = (r.FindControl("LinkButton2") as Button);
            TextBox T2 = (r.FindControl("TextBox1") as TextBox);
            bool res = b.UpdateVehicletype(T2.Text, int.Parse(lblId.CommandArgument));
            if (res)
            {
                Response.Write("<script>alert('Servicetype updated')</script>");
                GridView1.EditIndex = -1;
                Bindvehicletype();
            }
            else
            {
                Response.Write("<script>alert('Error..!!!!!')</script>");
                GridView1.EditIndex = -1;
                Bindvehicletype();
            }
        }
        protected void vehicletype_btn_Click(object sender, EventArgs e)
        {
            bool res;
            res = b.CheckVehicleType(txtvehicletype.Text);
            if (res == true)
            {
                Response.Write("<script>alert('Vehicle type Already uploaded')</script>");

            }
            else
            {

                bool n = b.Upload_VehicleType(txtvehicletype.Text);
                if (n == true)
                {
                    Response.Write("<script>alert('Vehicle type Uploaded')</script>");
                    txtvehicletype.Text = "";
                    Bindvehicletype();
                }
                else
                {
                    Response.Write("<script>alert('Error..!!')</script>");


                }
            }
        }
    }
}