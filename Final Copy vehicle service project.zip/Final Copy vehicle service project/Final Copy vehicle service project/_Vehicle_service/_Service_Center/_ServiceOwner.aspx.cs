﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _Vehicle_service._Service_Center
{
    public partial class _ServiceOwner : System.Web.UI.Page
    {
        bll b = new bll();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindServiceProvider();
            }

        }
        public void BindServiceProvider()
        {
            GridView1.DataSource = b._GetRegisterData("Service Provider");
            GridView1.DataBind();
        }
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            BindServiceProvider();//bindgridview will get the data source and bind it again
        }
    }
}