﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _Vehicle_service
{
    public partial class Register1 : System.Web.UI.Page
    {
        bll b = new bll();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void reg_btn_Click(object sender, EventArgs e)
        {
            bool res = b.CheckUseremail(txtemail.Text);
            if (res == true)
            {
                Response.Write("<script>alert('Email ID user Already registered')</script>");

            }
            else
            {

                bool n = b.user_register(DropDownList1.SelectedItem.Text,txtfirstname.Text,txtemail.Text, txtpassword.Text,txtcontact.Text);
                if (n == true)
                {
                    Response.Write("<script>alert('your successfully registered')</script>");
                }
                else
                {
                    Response.Write("<script>alert('Registration Error..!!')</script>");

                }
            }
        }
    }
}